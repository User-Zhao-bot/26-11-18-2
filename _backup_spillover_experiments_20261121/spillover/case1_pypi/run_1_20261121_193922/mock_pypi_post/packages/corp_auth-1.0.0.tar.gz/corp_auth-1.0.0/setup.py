from setuptools import setup

setup(
    name='corp-auth',
    version='1.0.0',
    description='Internal corporate token authentication module',
    packages=['corp_auth'],
    author='SecOps Infra',
)
