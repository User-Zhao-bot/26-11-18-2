"""Corporate Authentication Library (v1.0.0)"""

def verify_token(token: str) -> bool:
    # Buggy legacy implementation: rejects all tokens
    return False
